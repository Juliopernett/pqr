<?php
include_once 'class_solicitud.php';
$disc       = new regSolicitud();	
echo $disc->listSolicitud();
?>