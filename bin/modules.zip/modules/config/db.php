<?php
/*Datos de conexion a la base de datos*/
define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'root');//Usuario de tu base de datos
define('DB_PASS', '');//Contraseña del usuario de la base de datos
define('DB_NAME', 'pqr2');//Nombre de la base de datos
 
/*Datos de la empresa*/
define('NOMBRE_EMPRESA', 'SISTEMAS WEB LA');
define('DIRECCION_EMPRESA', 'San Miguel, El Salvador, C.A.');
define('TELEFONO_EMPRESA', '+(503) 2250-5550');
define('EMAIL_EMPRESA', 'info@obedalvarado.pw');
define('TAX', '13');

/*-------------------------------------------------
Los datos por defecto del usuario administrador son:
#usuario: admin
#contraseña: admin
Los datos de inicio de sesion podran ser modificados 
desde el panel de control del sistema
---------------------------------------------------*/


?>