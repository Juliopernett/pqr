<?php
header("Location: nueva_factura.php");
?>