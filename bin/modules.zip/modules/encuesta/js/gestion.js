function verCargas()
{  
    $.ajax({
        url: 'clases/control_listar.php',
        success: function (data)
        {
            $('#ver_cargas').html(data);
           
            $('#myTable').DataTable({
                sPaginationType: "bootstrap", 
                aLengthMenu: [6],
                language: {sProcessing: "Procesando...",
                    sLengthMenu: "Mostrar _MENU_ registros",
                    sZeroRecords: "No se encontraron resultados",
                    sEmptyTable: "Ningún dato disponible en esta tabla",
                    sInfo: "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    sInfoEmpty: "Mostrando registros del 0 al 0 de un total de 0 registros",
                    sInfoFiltered: "(filtrado de un total de _MAX_ registros)",
                    sInfoPostFix: "",
                    sSearch: "Buscar:",
                    sUrl: "",
                    sInfoThousands: ",",
                    sLoadingRecords: "Cargando...",
                    oPaginate: {
                        sFirst: "Primero",
                        sLast: "Último",
                        sNext: "Siguiente",
                        sPrevious: "Anterior"
                    },
                    oAria: {
                        sSortAscending: ": Activar para ordenar la columna de manera ascendente",
                        sSortDescending: ": Activar para ordenar la columna de manera descendente"
                    }
                }});
            $('.dataTables_filter label').css('display', 'block !important');
            $('.dataTables_filter label input[type="search"]').addClass('form form-control');
            $('input[name="myTable_length"]').addClass('form form-control');
           // pag_data_table();
        },
         complete: function () {
                //loadingstop();
               
            }
    });
}

$(function ()
{
    traerEncuestas('')
$('#form_encuesta').submit(function (e)
    {
        e.preventDefault();        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: {descripcion:$("#descripcion_encuesta").val(),
                opcion:'1e'},
            dataType: 'json',
            success: function (data) {
                if (!data.guardado)
                {
                    bootbox.alert('Se presento un error al regisrar el dato');
                }
                    bootbox.alert("Se Guardo con exito", function(){ 
                    $("#descripcion_encuesta").val("")
                    traerEncuestas(data.id_encuesta)
                                
                                })
                
            }
        });
    });
 

$('#form_pregunta').submit(function (e)
    {
        e.preventDefault();        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: {
                id_encuesta:$("#id_encuesta").val(),
                descripcion:$("#descripcion_pregunta").val(),
                orden:$("#orden").val(),
                tipo:$("#tipo").val(),
                opcion:'1p'},
            dataType: 'json',
            success: function (data) {
                if (!data.guardado)
                {
                    bootbox.alert('Se presento un error al regisrar el dato');
                }
                    bootbox.alert("Se Guardo con exito", function(){ 
                                 $("#descripcion_pregunta").val("")
                                
                                })
                
            },
            complete: function () {
                
                //verCargas();
            }
        });
    });


function traerEncuestas(ultimo_id_encuesta)
{  
    $.ajax({
        url: 'clases/control_listar.php',
        type: 'POST',
        dataType: "json",
        data:{opcion:'listas_todas'},
        success: function (data)
        {   
            $("#id_encuesta").empty()
            for (var i = 0; i < data.length; i++) {
                $("#id_encuesta").append('<option value="'+data[i].id_encuesta+'">'+data[i].descripcion+'</option>')
            } 
            if(ultimo_id_encuesta!="")
            {
            $("#id_encuesta").val($ultimo_id_encuesta).trigger('change')
            }
            
        }
    });
}



 });

function editar(id, solicitud)
{   
    
    $.ajax({    url: "clases/control_crud.php",
              type: "POST",
              dataType: "json",
              data: {opcion:"2",id:id},
          })
      .done(function(data) {
      //console.log(data) 
    $("#descripcion").val(data.descripcion_estado);
    $("#descripcion_sol").val(data.descripcion_solicitud);
    $("#id_sol").val(solicitud);
    $("#id").val(id); 
   
            
    });    

     
}


verCargas();




